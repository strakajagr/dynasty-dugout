# worker_function.py
# This is the complete code for your NEW Lambda function.
# Do NOT add this to your existing API code.

import logging
import json
import os
from datetime import datetime, timezone
from uuid import uuid4
from pydantic import BaseModel, Field
import boto3 # Ensure boto3 is available in your Lambda environment (it is by default)

# It is critical that this worker has access to your shared 'core' layer
# or that these utility files are included in its deployment package.
from core.database import execute_sql

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# =============================================================================
# PYDANTIC MODEL (Copied from lifecycle.py for validation)
# =============================================================================

class LeagueCreateRequest(BaseModel):
    league_name: str = Field(..., min_length=3, max_length=255)
    use_salaries: bool = Field(default=True)
    use_contracts: bool = Field(default=True)
    max_teams: int = Field(default=12, ge=4, le=20)
    use_waivers: bool = Field(default=False)
    salary_cap: float = Field(default=260.0)

# =============================================================================
# LAMBDA HANDLER (Entry point for the worker)
# =============================================================================

def lambda_handler(event, context):
    """
    Receives the event from the main API and starts the league creation process.
    """
    try:
        league_id = event['league_id']
        user_id = event['user_id']
        league_data_dict = event['league_data']

        logger.info(f"[{league_id[:8]}] WORKER: Invoked for league creation.")

        # This is the main function that does all the heavy lifting
        create_league_database_and_tables(league_id, league_data_dict, user_id)

        logger.info(f"[{league_id[:8]}] WORKER: Process completed successfully.")
        return {'statusCode': 200, 'body': json.dumps('League creation successful.')}

    except Exception as e:
        # The main function will handle updating the DB status to 'failed'.
        # This log is for CloudWatch to clearly mark the Lambda execution failure.
        logger.error(f"[{event.get('league_id', 'UNKNOWN')[:8]}] WORKER: A fatal, unhandled error occurred: {e}", exc_info=True)
        # It's important to re-raise the exception to ensure the Lambda invocation is marked as a failure.
        raise

# =============================================================================
# WORKER LOGIC (Copied and adapted from lifecycle.py)
# =============================================================================

def create_league_database_and_tables(league_id: str, league_data_dict: dict, user_id: str):
    """Main workflow for creating and populating a new league database. To be run by a worker."""
    database_name = f"league_{league_id.replace('-', '_')}"
    # Validate the incoming data using the Pydantic model
    league_data = LeagueCreateRequest(**league_data_dict)

    try:
        logger.info(f"[{league_id[:8]}] WORKER: 🚀 Starting league creation process...")

        # 1. Create the League Database
        try:
            execute_sql(f'CREATE DATABASE "{database_name}"', database_name='postgres')
            logger.info(f"[{league_id[:8]}] WORKER: ✅ Database {database_name} created.")
        except Exception as db_error:
            # Check for a specific part of the error message to avoid false positives
            if "already exists" not in str(db_error):
                raise db_error
            logger.warning(f"[{league_id[:8]}] WORKER: ⚠️ Database {database_name} already exists. Proceeding with setup.")

        # 2. Create All Tables
        table_sqls = get_full_schema_sqls()
        for i, sql in enumerate(table_sqls, 1):
            execute_sql(sql, database_name=database_name)
            logger.info(f"[{league_id[:8]}] WORKER: Created table {i}/{len(table_sqls)}.")
        logger.info(f"[{league_id[:8]}] WORKER: ✅ All {len(table_sqls)} tables created.")

        # 3. Populate Data
        load_all_mlb_players(database_name, league_id)
        sync_player_stats(database_name, league_id)

        # 4. Insert Settings
        settings = [
            (league_id, 'league_name', league_data.league_name, 'string'),
            (league_id, 'use_salaries', str(league_data.use_salaries), 'boolean'),
            (league_id, 'use_contracts', str(league_data.use_contracts), 'boolean'),
            (league_id, 'use_waivers', str(league_data.use_waivers), 'boolean'),
            (league_id, 'max_teams', str(league_data.max_teams), 'integer'),
        ]
        settings_values = [f"('{val[0]}'::uuid, '{val[1]}', '{val[2]}', '{val[3]}')" for val in settings]
        execute_sql(f"INSERT INTO league_settings (league_id, setting_name, setting_value, setting_type) VALUES {', '.join(settings_values)}", database_name=database_name)
        logger.info(f"[{league_id[:8]}] WORKER: ✅ League settings inserted.")

        # 5. Create Commissioner Team
        execute_sql("""
            INSERT INTO league_teams (league_id, user_id, team_name, is_commissioner, slot_number)
            VALUES (:league_id::uuid, :user_id, 'Commissioner Team', true, 1)
        """, {'league_id': league_id, 'user_id': user_id}, database_name=database_name)
        logger.info(f"[{league_id[:8]}] WORKER: ✅ Commissioner team created.")

        # 6. FINAL STEP: Update status to 'completed'
        execute_sql(
            "UPDATE user_leagues SET creation_status = 'completed', status_last_updated_at = NOW() WHERE league_id = :league_id::uuid",
            {'league_id': league_id}, 'postgres'
        )
        logger.info(f"[{league_id[:8]}] WORKER: 🎉 League creation successful! Status updated in phone book.")

    except Exception as e:
        error_msg = f"Worker process failed: {str(e)}"
        logger.error(f"[{league_id[:8]}] WORKER: 💥 FATAL ERROR: {error_msg}", exc_info=True)

        # Update status to 'failed' with error message in the main database
        execute_sql(
            "UPDATE user_leagues SET creation_status = 'failed', creation_error_message = :error, status_last_updated_at = NOW() WHERE league_id = :league_id::uuid",
            {'league_id': league_id, 'error': error_msg}, 'postgres'
        )

        # Attempt cleanup of the potentially partially created database
        try:
            logger.warning(f"[{league_id[:8]}] WORKER: Attempting cleanup of failed database '{database_name}'...")
            execute_sql(f'DROP DATABASE IF EXISTS "{database_name}"', database_name='postgres')
            logger.info(f"[{league_id[:8]}] WORKER: Cleanup successful.")
        except Exception as cleanup_e:
            logger.error(f"[{league_id[:8]}] WORKER: ⚠️ Cleanup failed for database {database_name}: {cleanup_e}")

        # Re-raise the exception to ensure the Lambda execution is marked as failed in CloudWatch
        raise e

# =============================================================================
# Helper functions (These are the long-running tasks)
# =============================================================================

def get_full_schema_sqls() -> list[str]:
    """Returns the complete list of CREATE TABLE statements for a new league database."""
    # This function's content remains exactly the same as in lifecycle.py
    return [
        """CREATE TABLE IF NOT EXISTS league_settings (
            setting_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            league_id UUID NOT NULL,
            setting_name VARCHAR(100) NOT NULL,
            setting_value TEXT,
            setting_type VARCHAR(50) DEFAULT 'string',
            category VARCHAR(50),
            description TEXT,
            last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )""",
        """CREATE TABLE IF NOT EXISTS league_teams (
            team_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            league_id UUID NOT NULL,
            user_id VARCHAR(255) NOT NULL,
            team_name VARCHAR(255),
            manager_name VARCHAR(255),
            is_commissioner BOOLEAN DEFAULT FALSE,
            is_active BOOLEAN DEFAULT TRUE,
            slot_number INTEGER,
            total_salary DECIMAL(12,2) DEFAULT 0,
            roster_spots_used INTEGER DEFAULT 0,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )""",
        """CREATE TABLE IF NOT EXISTS league_players (
            league_player_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            mlb_player_id INTEGER NOT NULL,
            team_id UUID,
            salary DECIMAL(8,2) DEFAULT 1.0,
            contract_years INTEGER DEFAULT 1,
            contract_start_date DATE,
            contract_end_date DATE,
            availability_status VARCHAR(20) DEFAULT 'free_agent',
            roster_status VARCHAR(20) DEFAULT 'active',
            acquisition_date TIMESTAMP WITH TIME ZONE,
            acquisition_method VARCHAR(20),
            acquisition_cost DECIMAL(8,2),
            fantasy_points DECIMAL(8,2) DEFAULT 0,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            CONSTRAINT unique_mlb_player_id UNIQUE(mlb_player_id)
        )""",
        """CREATE TABLE IF NOT EXISTS league_transactions (
            transaction_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            league_player_id UUID NOT NULL,
            from_team_id UUID,
            to_team_id UUID,
            transaction_type VARCHAR(20) NOT NULL,
            transaction_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            processed_date TIMESTAMP WITH TIME ZONE,
            salary DECIMAL(8,2),
            contract_years INTEGER,
            notes TEXT,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )""",
        """CREATE TABLE IF NOT EXISTS player_season_stats (
            season_stat_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            player_id INTEGER NOT NULL,
            season_year INTEGER NOT NULL DEFAULT 2025,
            games_played INTEGER DEFAULT 0, at_bats INTEGER DEFAULT 0, hits INTEGER DEFAULT 0,
            runs INTEGER DEFAULT 0, rbi INTEGER DEFAULT 0, home_runs INTEGER DEFAULT 0,
            doubles INTEGER DEFAULT 0, triples INTEGER DEFAULT 0, stolen_bases INTEGER DEFAULT 0,
            walks INTEGER DEFAULT 0, strikeouts INTEGER DEFAULT 0, avg NUMERIC(5,3) DEFAULT 0.000,
            obp NUMERIC(5,3) DEFAULT 0.000, slg NUMERIC(5,3) DEFAULT 0.000, ops NUMERIC(5,3) DEFAULT 0.000,
            games_started INTEGER DEFAULT 0, innings_pitched NUMERIC(6,1) DEFAULT 0.0,
            wins INTEGER DEFAULT 0, losses INTEGER DEFAULT 0, saves INTEGER DEFAULT 0,
            holds INTEGER DEFAULT 0, quality_starts INTEGER DEFAULT 0, earned_runs INTEGER DEFAULT 0,
            hits_allowed INTEGER DEFAULT 0, walks_allowed INTEGER DEFAULT 0, strikeouts_pitched INTEGER DEFAULT 0,
            era NUMERIC(5,2) DEFAULT 0.00, whip NUMERIC(5,3) DEFAULT 0.000,
            last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            CONSTRAINT unique_player_season UNIQUE(player_id, season_year)
        )""",
        """CREATE TABLE IF NOT EXISTS player_daily_team_stats (
            daily_stat_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            mlb_player_id INTEGER NOT NULL,
            team_id UUID NOT NULL,
            game_date DATE NOT NULL,
            at_bats INTEGER DEFAULT 0, hits INTEGER DEFAULT 0, doubles INTEGER DEFAULT 0,
            triples INTEGER DEFAULT 0, home_runs INTEGER DEFAULT 0, rbi INTEGER DEFAULT 0,
            runs INTEGER DEFAULT 0, walks INTEGER DEFAULT 0, strikeouts INTEGER DEFAULT 0,
            stolen_bases INTEGER DEFAULT 0, innings_pitched DECIMAL(4,1) DEFAULT 0,
            wins INTEGER DEFAULT 0, losses INTEGER DEFAULT 0, saves INTEGER DEFAULT 0,
            earned_runs INTEGER DEFAULT 0, hits_allowed INTEGER DEFAULT 0,
            walks_allowed INTEGER DEFAULT 0, strikeouts_pitched INTEGER DEFAULT 0,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )""",
        """CREATE TABLE IF NOT EXISTS player_team_accumulated_stats (
            accumulated_stat_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            mlb_player_id INTEGER NOT NULL, team_id UUID NOT NULL,
            first_game_date DATE, last_game_date DATE, team_games_played INTEGER DEFAULT 0,
            team_at_bats INTEGER DEFAULT 0, team_hits INTEGER DEFAULT 0, team_home_runs INTEGER DEFAULT 0,
            team_rbi INTEGER DEFAULT 0, team_runs INTEGER DEFAULT 0, team_stolen_bases INTEGER DEFAULT 0,
            team_batting_avg DECIMAL(4,3) DEFAULT 0.000, team_innings_pitched DECIMAL(5,1) DEFAULT 0,
            team_wins INTEGER DEFAULT 0, team_losses INTEGER DEFAULT 0, team_saves INTEGER DEFAULT 0,
            team_earned_runs INTEGER DEFAULT 0, team_strikeouts_pitched INTEGER DEFAULT 0,
            team_era DECIMAL(4,2) DEFAULT 0.00, team_whip DECIMAL(4,3) DEFAULT 0.000,
            last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )""",
        """CREATE TABLE IF NOT EXISTS league_standings (
            standing_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), team_id UUID NOT NULL,
            category VARCHAR(50) NOT NULL, value DECIMAL(10,4), rank INTEGER, points INTEGER,
            calculation_date DATE DEFAULT CURRENT_DATE,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )""",
        """CREATE TABLE IF NOT EXISTS league_messages (
            message_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), league_id UUID NOT NULL,
            user_id VARCHAR(255) NOT NULL, message_text TEXT,
            message_type VARCHAR(50) DEFAULT 'general',
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )""",
        """CREATE TABLE IF NOT EXISTS league_invitations (
            invitation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), league_id UUID NOT NULL,
            email VARCHAR(255) NOT NULL, owner_name VARCHAR(255) NOT NULL,
            status VARCHAR(20) DEFAULT 'pending', invited_by VARCHAR(255) NOT NULL,
            invited_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )"""
    ]

def load_all_mlb_players(database_name: str, league_id: str):
    """Loads all active MLB players into the league with default fantasy values."""
    # This function's content remains exactly the same as in lifecycle.py
    try:
        logger.info(f"[{league_id[:8]}] WORKER: ⚾ Loading all MLB players...")
        all_players = execute_sql("SELECT player_id FROM mlb_players WHERE is_active = true", database_name='postgres')
        if not all_players or not all_players.get("records"):
            logger.warning(f"[{league_id[:8]}] WORKER: No active MLB players found to load.")
            return 0

        values_list = [f"({int(rec[0]['longValue'])})" for rec in all_players["records"]]
        total_players = len(values_list)
        logger.info(f"[{league_id[:8]}] WORKER: Found {total_players} players. Inserting in batches of 500...")

        for i in range(0, total_players, 500):
            chunk = values_list[i:i+500]
            batch_sql = f"INSERT INTO league_players (mlb_player_id) VALUES {', '.join(chunk)} ON CONFLICT (mlb_player_id) DO NOTHING"
            execute_sql(batch_sql, database_name=database_name)
            logger.info(f"[{league_id[:8]}] WORKER: Inserted batch {i//500 + 1}...")

        logger.info(f"[{league_id[:8]}] WORKER: ✅ Loaded {total_players} MLB players.")
        return total_players
    except Exception as e:
        logger.error(f"[{league_id[:8]}] WORKER: ⚠️ Error loading MLB players: {str(e)}")
        raise e

def sync_player_stats(database_name: str, league_id: str):
    """Syncs 2025 player stats from the main DB to the new league DB in batches."""
    # This function's content remains exactly the same as in lifecycle.py
    try:
        logger.info(f"[{league_id[:8]}] WORKER: 📊 Syncing 2025 player stats...")
        main_stats = execute_sql("SELECT * FROM player_stats WHERE season = 2025", database_name='postgres')
        if not main_stats or not main_stats.get('records'):
            logger.warning(f"[{league_id[:8]}] WORKER: ⚠️ No 2025 stats found to sync.")
            return 0

        all_records = main_stats['records']
        total_records, synced_count = len(all_records), 0
        logger.info(f"[{league_id[:8]}] WORKER: Found {total_records} stat records to sync. Processing in batches of 200...")

        for i in range(0, total_records, 200):
            batch = all_records[i:i + 200]
            values_list = []
            for record in batch:
                # Helper to safely extract values from the RDS Data API response format
                def get_val(r, index, type_key='longValue', default=0):
                    # Check for index out of bounds, key existence, and the 'isNull' flag
                    if index < len(r) and r[index] and not r[index].get('isNull', False) and type_key in r[index]:
                        return r[index][type_key]
                    return default

                # This mapping needs to be precise and match the player_stats table schema
                values_str = ", ".join(map(str, [
                    get_val(record, 1), get_val(record, 2), get_val(record, 3), get_val(record, 4),
                    get_val(record, 5), get_val(record, 7), get_val(record, 6), get_val(record, 8),
                    get_val(record, 9), get_val(record, 10), get_val(record, 11), get_val(record, 12),
                    get_val(record, 13), f"'{get_val(record, 14, 'stringValue', '0.000')}'",
                    f"'{get_val(record, 15, 'stringValue', '0.000')}'", f"'{get_val(record, 16, 'stringValue', '0.000')}'",
                    f"'{get_val(record, 17, 'stringValue', '0.000')}'", get_val(record, 18),
                    f"'{get_val(record, 19, 'stringValue', '0.0')}'", get_val(record, 20), get_val(record, 21),
                    get_val(record, 22), get_val(record, 23), get_val(record, 32), get_val(record, 24),
                    get_val(record, 25), get_val(record, 26), get_val(record, 27),
                    f"'{get_val(record, 28, 'stringValue', '0.00')}'", f"'{get_val(record, 29, 'stringValue', '0.000')}'",
                ]))
                values_list.append(f"({values_str}, NOW())")

            if values_list:
                batch_sql = f"""
                    INSERT INTO player_season_stats (
                        player_id, season_year, games_played, at_bats, hits, runs, rbi, home_runs,
                        doubles, triples, stolen_bases, walks, strikeouts, avg, obp, slg, ops,
                        games_started, innings_pitched, wins, losses, saves, holds, quality_starts,
                        earned_runs, hits_allowed, walks_allowed, strikeouts_pitched, era, whip, last_updated
                    ) VALUES {', '.join(values_list)} ON CONFLICT (player_id, season_year) DO NOTHING
                """
                execute_sql(batch_sql, database_name=database_name)
                synced_count += len(values_list)
                logger.info(f"[{league_id[:8]}] WORKER: Synced batch {i//200 + 1}...")

        logger.info(f"[{league_id[:8]}] WORKER: ✅ Synced {synced_count} player stats records.")
        return synced_count
    except Exception as e:
        logger.error(f"[{league_id[:8]}] WORKER: 💥 FATAL: Error syncing player stats: {str(e)}")
        raise e
